#!/bin/bash
mkdir -p logs
exec >> "logs/feature_counts.log" 2>&1

# module load samtools || { echo "Failed to load samtools module"; exit 1; } # For featureCounts
# module load hisat2 || { echo "Failed to load hisat2 module"; exit 1; }

module load anaconda/3-2022.05 || { echo "Failed to load anaconda module"; exit 1; } 
echo "modules loaded"

# Set directories
input_dir="/scratch/aubzxk001/embryo_transcriptome/hisat2_bam"
ref_dir="/home/aubzxk001/Cells_ARV_RNASeq_2023/reference_genome/ncbi_dataset/data"
ref_file="GCF_016699485.2_bGalGal1.mat.broiler.GRCg7b_genomic.fna"
index_dir="/home/aubzxk001/Cells_ARV_RNASeq_2023/hisat2/galgal_index"
gtf_file="/home/aubzxk001/Cells_ARV_RNASeq_2023/reference_genome/ncbi_dataset/data/GCF_016699485.2_bGalGal1.mat.broiler.GRCg7b_genomic.gtf"
bam_dir="/scratch/aubzxk001/embryo_transcriptome/hisat2_bam"
counts_dir="/scratch/aubzxk001/embryo_transcriptome/hisat_feature_counts"

# Create output directory for feature counts
mkdir -p "$counts_dir"

# Function to process each sample
process_sample() {
    base=$1
    bam_file="${bam_dir}/${base}.sorted.bam"
   
    echo "Processing sample ${base}."

    # Define output count file
    counts_file="${counts_dir}/${base}_counts.tsv"

    # Count with featureCounts
    if ! featureCounts -T 12 -p -a "$gtf_file" -o "$counts_file" "$bam_file"; then
       echo "featureCounts failed for sample ${base}"; exit 1
    fi
}

MAX_JOBS=8  # Adjust based on system capacity

for bam_file in $bam_dir/*.sorted.bam
do
    base=$(basename $bam_file .sorted.bam)
    process_sample $base &

    # If we've reached MAX_JOBS, wait for some to finish
    if [[ $(jobs -r -p | wc -l) -ge $MAX_JOBS ]]; then
        wait -n  # Wait for any job to finish before starting a new one
    fi
done

echo "$(date):feature counting completed."
echo "__________________________________________________________________________________________"
