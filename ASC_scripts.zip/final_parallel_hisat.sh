#!/bin/bash
exec >> "logs/final_hisat.log" 2>&1

module load samtools || { echo "Failed to load samtools module"; exit 1; } # For featureCounts
module load hisat2 || { echo "Failed to load hisat2 module"; exit 1; }

echo "modules loaded"

# Set directories
input_dir="/scratch/aubzxk001/embryo_transcriptome/adapter_and_quality_trimmed/unzipped"
index_dir="/home/aubzxk001/Cells_ARV_RNASeq_2023/hisat2/galgal_index"
bam_dir="/scratch/aubzxk001/embryo_transcriptome/hisat2_bam"

# Create output directory for feature counts
mkdir -p "$bam_dir"

# Maximum number of parallel jobs
max_jobs=10
running_jobs=0

# Process each sample in parallel
for fastq1 in "$input_dir"/*_R1.fastq; do
    base=$(basename "$fastq1" _R1.fastq)
    fastq2="${input_dir}/${base}_R2.fastq"
   
    echo "Processing sample ${base}."

    # Run HISAT2 alignment and sorting in the background
    (hisat2 -p 12 --dta -x "$index_dir/galgal_index" -1 "$fastq1" -2 "$fastq2" | \
     samtools sort -@ 11 -m 1G -o "${bam_dir}/${base}.sorted.bam") &
     
    # Increment the job counter
    ((running_jobs++))

    # If max_jobs is reached, wait for jobs to finish
    if ((running_jobs >= max_jobs)); then
        wait
        running_jobs=0
    fi
done

# Wait for any remaining background jobs to finish
wait

echo "All samples processed."
