#!/bin/bash
exec >> "logs/log_trimmomatic_$(date +%Y%m%d%H%M%S).log" 2>&1

source /apps/profiles/modules_asax.sh.dyn
module load trimmomatic

# Directory containing your FASTQ files
input_dir="/home/aubzxk001/hauck_research/Embryo_ARV_Transcriptome_ZK/raw_fastq"

trimmed_reads_dir="/scratch/aubzxk001/embryo_transcriptome/adapter_and_quality_trimmed"

mkdir -p "$trimmed_reads_dir"

# Process each pair of FASTQ files in the directory
for file1 in "$input_dir"/*_R1_001.fastq.gz; do
    # Get the base name of the file
    base_name=$(basename "$file1" _R1_001.fastq.gz)
    echo "$base_name"
    file2="${input_dir}/${base_name}_R2_001.fastq.gz"

    if [[ -f "$file1" && -f "$file2" ]]; then
        # Quality control and trimming using Trimmomatic
        trimmed_file1="${trimmed_reads_dir}/${base_name}_R1.fastq.gz"
        trimmed_file2="${trimmed_reads_dir}/${base_name}_R2.fastq.gz"
        
        # Run trimmomatic without unpaired reads
        trimmomatic PE -threads 32 -phred33 \
            "$file1" "$file2" \
            "$trimmed_file1" /dev/null \
            "$trimmed_file2" /dev/null \
            ILLUMINACLIP:adapters.fa:2:30:10:8:true LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:50
        
        # Check if trimming succeeded
        if [[ $? -ne 0 ]]; then
            echo "Trimmomatic failed for $base_name"
            continue
        fi
        
        # Count total reads in raw data
        total_reads=$(zcat "$file1" "$file2" | wc -l)
        total_reads=$((total_reads / 4))
        echo "Processing sample ${base_name} with ${total_reads} total reads"
    
    else 
        echo "Paired files not found for $base_name"
    fi
done
