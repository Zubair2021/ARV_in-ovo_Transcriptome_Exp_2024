#!/bin/bash
#source /apps/x86-64/etc/modulefiles/fastqc/0.10.1.lua

module load fastqc

# Create a directory for temporary cache storage
mkdir -p /home/aubzxk001/tmp
export _JAVA_OPTIONS="-Djava.io.tmpdir=/home/aubzxk001/tmp"
exec >> logs/fastqc.log 2>&1

# Directory containing the raw data
RAW_DATA_DIR="/home/aubzxk001/hauck_research/Embryo_ARV_Transcriptome_ZK/raw_fastq"
# Directory to store the FastQC results
RESULTS_DIR="/scratch/aubzxk001/embryo_transcriptome/fastqc_results"
mkdir -p $RESULTS_DIR

# Run FastQC on each file
for file in $RAW_DATA_DIR/*.fastq.gz
do
    fastqc -t 32 -o $RESULTS_DIR $file 
done
